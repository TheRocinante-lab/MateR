# MateR
 
<img src="images/Hex_MtR.png" alt="MateR hex sticker"
     style="width:200px;height:auto;" align="right" />
Genomic Mating package. Optimize mating plans using genomic information to maximize genetic gain, within-family variance, and genetic diversity. Supports polyploids, multi-trait optimization, additive and dominance effects, directional dominance (inbreeding and heterosis), and testers.

Documentation and examples of MateR usage are available in the Vignette.

<br>

<br>


## Installation

Please, see Installation.txt for instructions on how to install MateR.

Make sure you have the TrainSel package installed. More details in https://github.com/TheRocinante-lab/TrainSel

## Citation: 

Fernández-González J, Metwally SM, Isidro Y Sánchez J. MateR: a novel genomic mating framework. Genetics. 2026 Jan 19:iyag013. doi: 10.1093/genetics/iyag013